﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsIzmenaNabavke
    {

        private string pStringKonekcije;
        private clsNabavkaDB objNabavkaDB;

        private clsNabavka objPreuzetaNabavka;
        private clsNabavka objIzmenjenaNabavka;

        private string pNazivPreuzeteMasine;
        private string pSifraPreuzetogUvoznika;
        private string pKolicinaPreuzeta;

        private string pNazivIzmenjeneMasine;
        private string pSifraIzmenjenogUvoznika;
        private string pKolicinaIzmenjena;

        public string NazivPreuzeteMasine
        {
            get { return pNazivPreuzeteMasine; }
            set { pNazivPreuzeteMasine = value; 
                pSifraPreuzetogUvoznika = objNabavkaDB.DajSifruUvoznikaPoNazivuMasine(pNazivPreuzeteMasine).ToString(); 
                pKolicinaPreuzeta = objNabavkaDB.DajKolicinuPoNazivuMasine(pNazivPreuzeteMasine).ToString(); }
        }

        public string SifraPreuzetogUvoznika
        {
            get { return pSifraPreuzetogUvoznika; }
        }
       
        public string KolicinaPreuzeta
        {
            get { return pKolicinaPreuzeta; }
        }


        public string NazivIzmenjeneMasine
        {
            get { return pNazivIzmenjeneMasine; }
            set { pNazivIzmenjeneMasine = value; }
        }

        public string SifraIzmenjenogUvoznika
        {
            get { return pSifraIzmenjenogUvoznika; }
            set { pSifraIzmenjenogUvoznika = value; }
        }

        public string KolicinaIzmenjena
        {
            get { return pKolicinaIzmenjena; }
            set { pKolicinaIzmenjena = value; }
        }

        public clsIzmenaNabavke(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
            objNabavkaDB = new clsNabavkaDB(pStringKonekcije);
        }

        public bool ObrisiNabavku()
        {
            bool uspehBrisanja = false;
            uspehBrisanja =objNabavkaDB.ObrisiNabavku(pNazivPreuzeteMasine);

            return uspehBrisanja;
        }

        public bool IzmeniNabavku()
        {
            bool uspehIzmene = false;
            objPreuzetaNabavka = new clsNabavka();
            objIzmenjenaNabavka = new clsNabavka();

            objPreuzetaNabavka.NazivMasine = pNazivPreuzeteMasine;
            objPreuzetaNabavka.SifraUvoznika = pSifraPreuzetogUvoznika;
            objPreuzetaNabavka.Kolicina = pKolicinaPreuzeta;
            

            objIzmenjenaNabavka.NazivMasine = pNazivIzmenjeneMasine;
            objIzmenjenaNabavka.SifraUvoznika = pSifraIzmenjenogUvoznika;
            objIzmenjenaNabavka.Kolicina = pKolicinaIzmenjena;
       

            uspehIzmene = objNabavkaDB.IzmeniNabavku(objPreuzetaNabavka, objIzmenjenaNabavka);

            return uspehIzmene;
        }



    }
}
