﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsNabavkaStampaSpisak
    {
        #region
        private string pStringKonekcije;
        #endregion;

        public clsNabavkaStampaSpisak(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        public DataSet DajPodatkeZaGrid(string Filter)
        {
            DataSet dsPodaci = new DataSet();
            clsNabavkaDB objNabavkaDB = new clsNabavkaDB(pStringKonekcije);
            if (Filter.Equals(""))
            {
                dsPodaci = objNabavkaDB.DajSveNabavke();
            }
            else
            {
                dsPodaci = objNabavkaDB.DajNabavkuPoNazivuMasine(Filter); 
            }
            return dsPodaci;
        }
    }
}
