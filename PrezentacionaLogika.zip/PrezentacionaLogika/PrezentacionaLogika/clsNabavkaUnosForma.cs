﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class clsNabavkaUnosForma
    {
       private string pNazivMasine;
	   private DateTime pDatumNabavke; 
	   private string pSifraUvoznika; 
	   private string pCena;
       private string pKolicina; 

        private string pStringKonekcije;

        
        public clsNabavkaUnosForma(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        public string NazivMasine
        {
            get { return pNazivMasine; }
            set { pNazivMasine = value; }
        }

        public DateTime DatumNabavke
        {
            get { return pDatumNabavke; }
            set { pDatumNabavke = value; }
        }

        public string SifraUvoznika
        {
            get { return pSifraUvoznika; }
            set { pSifraUvoznika = value; }
        }

        public string Cena
        {
            get { return pCena; }
            set { pCena = value; }
        }

        public string Kolicina
        {
            get { return pKolicina; }
            set { pKolicina = value; }
        }

        public DataSet DajPodatkeZaCombo()
        {
            clsUvoznikDB objUvoznik = new clsUvoznikDB(pStringKonekcije);
            DataSet dsPodaci = new DataSet();
            dsPodaci = objUvoznik.DajSveUvoznike();

            return dsPodaci;
        }


        public bool DaLiSuPodaciIspravni()
        {

            bool IspravniPodaci = false;


            if ((this.pNazivMasine.Equals("")) || (this.pDatumNabavke.Equals("")) || (this.pSifraUvoznika.Equals("")) || (this.pCena.Equals("")) || (this.pKolicina == null))
            {
                IspravniPodaci = false;
            }
            else
            {


                int KolicinaInteger = 0;
                bool uspehKonvezijeUInt = int.TryParse(this.pKolicina, out KolicinaInteger);

                if (!uspehKonvezijeUInt)
                {
                    IspravniPodaci = false;
                }
                else
                {


                    if (this.pNazivMasine.Length > 3)
                    {
                        IspravniPodaci = false;
                    }
                    else
                    {

                        clsNabavkaDB objNabavkaDB = new clsNabavkaDB(pStringKonekcije);
                        DataSet dsPodaciNabavke = objNabavkaDB.DajNabavkuPoNazivuMasine(this.pNazivMasine);
                        bool NePostojiSifraUBazi = (dsPodaciNabavke.Tables[0].Rows.Count == 0);
                        IspravniPodaci = NePostojiSifraUBazi;

                    }
                }
            }

            return IspravniPodaci;
        }

        public bool SnimiPodatke()
        {
            bool uspeh = false;
            clsNabavkaDB objNabavkaDB = new clsNabavkaDB(pStringKonekcije);
            clsNabavka objNabavka = new clsNabavka();
     
            objNabavka.NazivMasine = this.pNazivMasine;
            objNabavka.DatumNabavke = this.pDatumNabavke;
            objNabavka.SifraUvoznika = this.pSifraUvoznika;
            objNabavka.Cena = this.Cena;
            objNabavka.Kolicina = this.Kolicina;

           
            uspeh = objNabavkaDB.SnimiNovuNabavku(objNabavka);


            return uspeh;
        }


    }
}
