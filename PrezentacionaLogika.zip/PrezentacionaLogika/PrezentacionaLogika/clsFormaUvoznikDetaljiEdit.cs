﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
// 
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
   public class clsFormaUvoznikDetaljiEdit
    {
        
        private string pStringKonekcije;
        private clsUvoznikDB objUvoznikDB;

        private clsUvoznik objPreuzetiUvoznik;
        private clsUvoznik objIzmenjeniUvoznik;

        private string pSifraPreuzetogUvoznika;
        private string pNazivPreuzetogUvoznika;

        private string pSifraIzmenjenogUvoznika;
        private string pNazivIzmenjenogUvoznika;
      

        public string SifraPreuzetogUvoznika
        {
            get { return pSifraPreuzetogUvoznika; }
            set { pSifraPreuzetogUvoznika = value; pNazivPreuzetogUvoznika = DajNaziv(pSifraPreuzetogUvoznika); }
        }

        public string NazivPreuzetogUvoznika
        {
            get { return pNazivPreuzetogUvoznika; }
         
        }

        public string SifraIzmenjenogUvoznika
        {
            get { return pSifraIzmenjenogUvoznika; }
            set { pSifraIzmenjenogUvoznika = value; }
        }


        public string NazivIzmenjenogUvoznika
        {
            get { return pNazivIzmenjenogUvoznika; }
            set { pNazivIzmenjenogUvoznika = value; }
        }


        public clsFormaUvoznikDetaljiEdit(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
            objUvoznikDB = new clsUvoznikDB(pStringKonekcije);
        }

        private string DajNaziv(string SifraUvoznika)
        {
            string pomNaziv ="";
            DataSet dsPodaci = new DataSet();
            pomNaziv = objUvoznikDB.DajNazivUvoznikaPremaSifriUvoznika(SifraUvoznika); 

            return pomNaziv;
        }

        public bool ObrisiUvoznika()
        {
            bool uspehBrisanja = false;
            uspehBrisanja = objUvoznikDB.ObrisiUvoznika(pSifraPreuzetogUvoznika);  

            return uspehBrisanja;

        }

        public bool IzmeniUvoznika()
        {
            bool uspehIzmene = false;
            objPreuzetiUvoznik = new clsUvoznik();
            objIzmenjeniUvoznik = new clsUvoznik();

            objPreuzetiUvoznik.IdUvoznika = pSifraPreuzetogUvoznika;
            objPreuzetiUvoznik.ImeUvoznika = pNazivPreuzetogUvoznika;

            objIzmenjeniUvoznik.IdUvoznika = pSifraIzmenjenogUvoznika;
            objIzmenjeniUvoznik.ImeUvoznika = pNazivIzmenjenogUvoznika;

            uspehIzmene = objUvoznikDB.IzmeniUvoznika(objPreuzetiUvoznik, objIzmenjeniUvoznik);  

            return uspehIzmene;
        }
    }
}
